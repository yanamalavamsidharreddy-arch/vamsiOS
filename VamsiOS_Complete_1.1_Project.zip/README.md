# VamsiOS 1.1 — Complete native launcher starter

This project builds a native Android launcher for Android 8.0+.

Included:
- Home-screen clock and date
- Automatically discovers launchable apps using Android's launcher activity list
- Opens installed apps when their icons are tapped
- Search filters the installed app list
- App library / favourites view
- Swipe up to open the full app list; swipe down to return
- Four-app dock based on available apps
- Light/dark appearance switch
- Home launcher intent filter so Android can offer VamsiOS as a default Home app

Important:
- This is a sideloadable launcher app, not a custom Android OS or ROM.
- Android notification access, overlays, lock-screen replacement, and true system-wide Dynamic Island behaviour are not included. Those require additional permission flows and device-specific testing.
- `QUERY_ALL_PACKAGES` is used so the launcher can discover apps on a personal sideloaded device. Google Play distribution has additional package-visibility policy requirements.
- App icons and labels are read from installed launcher activities; apps without a launcher activity are not shown.
- Test the debug APK on the target Moto device before setting it as the default Home app.

Build: `gradle assembleDebug`
APK: `app/build/outputs/apk/debug/app-debug.apk`
