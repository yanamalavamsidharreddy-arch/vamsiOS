package com.vamsios.launcher

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.Drawable
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.BatteryFull
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import android.content.pm.ResolveInfo
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlinx.coroutines.delay

data class LaunchApp(
    val label: String,
    val packageName: String,
    val icon: Bitmap
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { VamsiOSHome() }
    }
}

private fun drawableBitmap(drawable: Drawable): Bitmap {
    val width = (drawable.intrinsicWidth.takeIf { it > 0 } ?: 96).coerceAtMost(192)
    val height = (drawable.intrinsicHeight.takeIf { it > 0 } ?: 96).coerceAtMost(192)
    val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
    val canvas = Canvas(bitmap)
    drawable.setBounds(0, 0, width, height)
    drawable.draw(canvas)
    return bitmap
}

@Composable
private fun VamsiOSHome() {
    val context = LocalContext.current
    val pm = context.packageManager
    var apps by remember { mutableStateOf(emptyList<LaunchApp>()) }
    var query by remember { mutableStateOf("") }
    var showLibrary by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }
    var dark by remember { mutableStateOf(false) }
    var clock by remember { mutableStateOf(SimpleDateFormat("H:mm", Locale.getDefault()).format(Date())) }
    var date by remember { mutableStateOf(SimpleDateFormat("EEE, d MMM", Locale.getDefault()).format(Date())) }

    LaunchedEffect(Unit) {
        while (true) {
            val now = Date()
            clock = SimpleDateFormat("H:mm", Locale.getDefault()).format(now)
            date = SimpleDateFormat("EEE, d MMM", Locale.getDefault()).format(now)
            delay(15_000)
        }
    }

    LaunchedEffect(Unit) {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val resolved: List<ResolveInfo> = pm.queryIntentActivities(intent, 0)
        apps = resolved.mapNotNull { ri ->
            try {
                val pkg = ri.activityInfo.packageName
                LaunchApp(
                    label = ri.loadLabel(pm).toString(),
                    packageName = pkg,
                    icon = drawableBitmap(ri.loadIcon(pm))
                )
            } catch (_: Exception) { null }
        }.distinctBy { it.packageName }.sortedBy { it.label.lowercase(Locale.getDefault()) }
    }

    val bgTop = if (dark) Color(0xFF151820) else Color(0xFFF2F0EC)
    val bgBottom = if (dark) Color(0xFF252B35) else Color(0xFFE7E3DE)
    val ink = if (dark) Color(0xFFF4F2EF) else Color(0xFF252A30)
    val muted = if (dark) Color(0xFFB7BBC2) else Color(0xFF777D84)
    val card = if (dark) Color(0xFF343A45).copy(alpha = .82f) else Color.White.copy(alpha = .78f)

    MaterialTheme {
        Box(
            modifier = Modifier.fillMaxSize()
                .background(Brush.verticalGradient(listOf(bgTop, bgBottom)))
                .pointerInput(showLibrary) {
                    var total = 0f
                    detectVerticalDragGestures(
                        onVerticalDrag = { _, amount -> total += amount },
                        onDragEnd = {
                            if (total < -45f) showLibrary = true
                            if (total > 45f) showLibrary = false
                            total = 0f
                        }
                    )
                }
                .padding(horizontal = 22.dp)
        ) {
            Column(modifier = Modifier.fillMaxSize()) {
                Spacer(Modifier.height(16.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text(date, color = muted, fontSize = 16.sp)
                    Text("VamsiOS", color = ink, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                }
                Spacer(Modifier.height(54.dp))
                Text(clock, color = ink, fontSize = 66.sp, fontWeight = FontWeight.Light, letterSpacing = (-2).sp)
                Text("A little space, beautifully yours.", color = muted, fontSize = 16.sp, letterSpacing = 1.sp)
                Spacer(Modifier.height(32.dp))
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(30.dp)).background(card).padding(20.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(if (showLibrary) "Your apps, all in one place" else "Good to see you", color = ink, fontSize = 22.sp, fontWeight = FontWeight.Medium)
                        Text(if (showLibrary) "${apps.size} apps available" else "Your day, at a glance.", color = muted, fontSize = 15.sp)
                    }
                    Icon(Icons.Default.BatteryFull, contentDescription = "Battery", tint = muted)
                }
                Spacer(Modifier.height(34.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text(if (showLibrary) "App library" else "Favourites", color = ink, fontSize = 21.sp, fontWeight = FontWeight.Medium)
                    Text(if (showLibrary) "Home" else "See all", color = Color(0xFF71899B), fontSize = 16.sp,
                        modifier = Modifier.clickable { showLibrary = !showLibrary })
                }
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    placeholder = { Text("Search apps") },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                    shape = RoundedCornerShape(12.dp)
                )
                Spacer(Modifier.height(16.dp))
                val filtered = apps.filter { it.label.contains(query, ignoreCase = true) }
                val shown = if (showLibrary || query.isNotBlank()) filtered else {
                    val preferred = listOf("phone", "camera", "message", "chrome", "photo", "setting", "youtube", "music", "play store", "calendar", "clock", "file")
                    preferred.mapNotNull { key -> apps.firstOrNull { it.label.contains(key, true) } }.distinctBy { it.packageName }.take(12)
                        .ifEmpty { apps.take(12) }
                }
                if (apps.isEmpty()) {
                    Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
                        Text("Loading your apps…", color = muted)
                    }
                } else {
                    LazyVerticalGrid(
                        columns = GridCells.Fixed(4),
                        modifier = Modifier.weight(1f),
                        contentPadding = PaddingValues(bottom = 110.dp),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalArrangement = Arrangement.spacedBy(18.dp)
                    ) {
                        items(shown, key = { it.packageName }) { app ->
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier.fillMaxWidth().clickable {
                                    val launch = pm.getLaunchIntentForPackage(app.packageName)
                                    if (launch != null) {
                                        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                        context.startActivity(launch)
                                    }
                                }.padding(vertical = 3.dp)
                            ) {
                                Box(
                                    Modifier.size(66.dp).clip(RoundedCornerShape(20.dp))
                                        .background(card),
                                    contentAlignment = Alignment.Center
                                ) {
                                    androidx.compose.foundation.Image(
                                        bitmap = app.icon.asImageBitmap(),
                                        contentDescription = app.label,
                                        modifier = Modifier.size(42.dp)
                                    )
                                }
                                Spacer(Modifier.height(7.dp))
                                Text(app.label, color = muted, fontSize = 11.sp, maxLines = 1, textAlign = TextAlign.Center)
                            }
                        }
                    }
                }
            }

            Row(
                Modifier.align(Alignment.BottomCenter).fillMaxWidth().padding(bottom = 14.dp)
                    .clip(RoundedCornerShape(34.dp)).background(card).padding(horizontal = 12.dp, vertical = 13.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                val dockApps = listOf("phone", "camera", "message", "chrome")
                    .mapNotNull { key -> apps.firstOrNull { it.label.contains(key, true) } }
                    .distinctBy { it.packageName }
                dockApps.forEach { app ->
                    Box(Modifier.size(58.dp).clip(CircleShape).background(if (dark) Color.White.copy(alpha=.08f) else Color(0xFFE8E8ED))
                        .clickable {
                            pm.getLaunchIntentForPackage(app.packageName)?.let {
                                it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                context.startActivity(it)
                            }
                        }, contentAlignment = Alignment.Center) {
                        androidx.compose.foundation.Image(app.icon.asImageBitmap(), contentDescription = app.label, modifier = Modifier.size(34.dp))
                    }
                }
                Box(Modifier.size(44.dp).clip(CircleShape).clickable { showSettings = !showSettings }, contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.Settings, contentDescription = "Appearance", tint = ink)
                }
            }

            if (showSettings) {
                Surface(
                    modifier = Modifier.align(Alignment.BottomEnd).padding(bottom = 100.dp),
                    shape = RoundedCornerShape(22.dp),
                    color = card,
                    shadowElevation = 8.dp
                ) {
                    Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("Appearance", color = ink, fontWeight = FontWeight.SemiBold)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Dark appearance", color = ink, modifier = Modifier.weight(1f))
                            Switch(checked = dark, onCheckedChange = { dark = it })
                        }
                        Text("Swipe up to open all apps", color = muted, fontSize = 12.sp)
                        Text("Tap See all to browse apps", color = muted, fontSize = 12.sp)
                    }
                }
            }
        }
    }
}
