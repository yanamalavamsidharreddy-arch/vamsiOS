package com.vamsios.launcher

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import android.content.Intent
import android.content.pm.PackageManager

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { VamsiOSHome() }
    }
}

private data class AppEntry(val label: String, val icon: ImageVector, val pkg: String? = null)

@Composable
private fun VamsiOSHome() {
    val context = LocalContext.current
    var drawer by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }
    var search by remember { mutableStateOf("") }
    val apps = remember {
        listOf(
            AppEntry("Phone", Icons.Default.Call, "com.google.android.dialer"),
            AppEntry("Messages", Icons.Default.Message, "com.google.android.apps.messaging"),
            AppEntry("Camera", Icons.Default.CameraAlt, "com.android.camera2"),
            AppEntry("Photos", Icons.Default.Photo, "com.google.android.apps.photos"),
            AppEntry("Chrome", Icons.Default.Language, "com.android.chrome"),
            AppEntry("Settings", Icons.Default.Settings, "com.android.settings"),
            AppEntry("Play Store", Icons.Default.ShoppingBag, "com.android.vending"),
            AppEntry("Clock", Icons.Default.Schedule, "com.google.android.deskclock"),
            AppEntry("Files", Icons.Default.Folder, "com.google.android.documentsui"),
            AppEntry("YouTube", Icons.Default.PlayCircle, "com.google.android.youtube"),
            AppEntry("Calendar", Icons.Default.CalendarMonth, "com.google.android.calendar"),
            AppEntry("Contacts", Icons.Default.Contacts, "com.google.android.contacts")
        )
    }
    val bg = Brush.verticalGradient(listOf(Color(0xFFF5F2EC), Color(0xFFE7E9E8), Color(0xFFDDE4E4)))
    Box(Modifier.fillMaxSize().background(bg)) {
        Column(Modifier.fillMaxSize().padding(horizontal = 22.dp, vertical = 18.dp)) {
            Spacer(Modifier.height(12.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text("VamsiOS", fontSize = 26.sp, fontWeight = FontWeight.SemiBold, color = Color(0xFF20272B))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Wifi, null, tint = Color(0xFF303B40), modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(7.dp))
                    Icon(Icons.Default.BatteryFull, null, tint = Color(0xFF303B40), modifier = Modifier.size(20.dp))
                }
            }
            Spacer(Modifier.height(22.dp))
            Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(30.dp)).background(Color(0xCC252B31)).padding(14.dp), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("GOOD DAY", color = Color(0xFFCFD6D5), fontSize = 10.sp, letterSpacing = 3.sp)
                    Text("Make today yours.", color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Medium)
                }
            }
            Spacer(Modifier.height(24.dp))
            Text("Favourites", fontSize = 18.sp, fontWeight = FontWeight.SemiBold, color = Color(0xFF273238))
            Spacer(Modifier.height(14.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                apps.take(4).forEach { AppTile(it) { launch(context, it.pkg) } }
            }
            Spacer(Modifier.weight(1f))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
                DockTile(Icons.Default.Call, "Phone") { launch(context, "com.google.android.dialer") }
                DockTile(Icons.Default.Message, "Messages") { launch(context, "com.google.android.apps.messaging") }
                DockTile(Icons.Default.Language, "Browser") { launch(context, "com.android.chrome") }
                DockTile(Icons.Default.CameraAlt, "Camera") { launch(context, "com.android.camera2") }
            }
            Spacer(Modifier.height(14.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
                TextButton(onClick = { drawer = !drawer }) { Icon(Icons.Default.Apps, null); Spacer(Modifier.width(8.dp)); Text(if (drawer) "Close apps" else "All apps") }
                TextButton(onClick = { showSettings = true }) { Icon(Icons.Default.Tune, null); Spacer(Modifier.width(6.dp)); Text("Customize") }
            }
        }
        if (drawer) {
            Column(Modifier.fillMaxSize().background(Color(0xFFF7F7F3)).padding(22.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("App Library", fontSize = 25.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                    IconButton(onClick = { drawer = false }) { Icon(Icons.Default.Close, null) }
                }
                OutlinedTextField(value = search, onValueChange = { search = it }, modifier = Modifier.fillMaxWidth(), placeholder = { Text("Search apps") }, leadingIcon = { Icon(Icons.Default.Search, null) }, singleLine = true)
                Spacer(Modifier.height(12.dp))
                LazyVerticalGrid(columns = GridCells.Fixed(3), verticalArrangement = Arrangement.spacedBy(18.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(apps.filter { it.label.contains(search, true) }) { app -> AppTile(app) { launch(context, app.pkg) } }
                }
            }
        }
        if (showSettings) {
            AlertDialog(
                onDismissRequest = { showSettings = false },
                title = { Text("VamsiOS settings") },
                text = { Text("This is the first native launcher build. More themes, gestures and widgets will be added in later versions.") },
                confirmButton = { TextButton(onClick = { showSettings = false }) { Text("Done") } }
            )
        }
    }
}

@Composable
private fun AppTile(app: AppEntry, onClick: () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.width(70.dp).clickable(onClick = onClick).animateContentSize()) {
        Box(Modifier.size(58.dp).clip(RoundedCornerShape(19.dp)).background(Color(0xEFFFFFFF)), contentAlignment = Alignment.Center) {
            Icon(app.icon, null, tint = Color(0xFF43545A), modifier = Modifier.size(29.dp))
        }
        Spacer(Modifier.height(6.dp))
        Text(app.label, fontSize = 11.sp, color = Color(0xFF273238), maxLines = 1)
    }
}

@Composable
private fun DockTile(icon: ImageVector, label: String, onClick: () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.clickable(onClick = onClick)) {
        Box(Modifier.size(58.dp).clip(RoundedCornerShape(20.dp)).background(Color(0xDFFFFFFF)), contentAlignment = Alignment.Center) {
            Icon(icon, null, tint = Color(0xFF43545A), modifier = Modifier.size(28.dp))
        }
        Spacer(Modifier.height(4.dp))
        Text(label, fontSize = 10.sp, color = Color(0xFF344147))
    }
}

private fun launch(context: android.content.Context, pkg: String?) {
    if (pkg == null) return
    val intent = context.packageManager.getLaunchIntentForPackage(pkg)
    if (intent != null) context.startActivity(intent)
    else context.startActivity(Intent(android.provider.Settings.ACTION_SETTINGS))
}
