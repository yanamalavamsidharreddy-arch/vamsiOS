# VamsiOS

A first native Android launcher prototype built with Kotlin and Jetpack Compose.

## Build
The GitHub Actions workflow builds a debug APK when code is pushed to `main`, or when manually started from the Actions tab.

APK output: `app/build/outputs/apk/debug/app-debug.apk`

## Install
Download the `VamsiOS-debug-apk` artifact from a completed Actions run, extract it, and install the APK on your Android phone. Android may ask you to allow installation from the app used to open the APK.

## Notes
- This is a launcher app, not a replacement Android operating system or custom ROM.
- Choose VamsiOS as the Home app in Android settings after installation.
- Some listed apps may use different package names on different phones; unavailable apps fall back to Android Settings.
