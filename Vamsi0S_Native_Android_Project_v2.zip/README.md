# VamsiOS native Android starter
Package: `com.vamsios.launcher`

This is a first native launcher shell with a home screen, clock/date, favourites grid and searchable app-library screen. It is not a replacement Android OS. The displayed app tiles are currently visual placeholders; launching installed apps and deeper system integrations are later development tasks.

GitHub Actions builds a debug APK and uploads it as an artifact.
