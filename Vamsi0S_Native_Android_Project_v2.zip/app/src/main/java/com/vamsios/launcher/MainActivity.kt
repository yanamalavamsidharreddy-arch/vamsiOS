package com.vamsios.launcher

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { HomeScreen() }
    }
}
private data class AppIcon(val title: String, val glyph: String, val color: Color)

@Composable
private fun HomeScreen() {
    val apps = listOf(
        AppIcon("Phone","☎",Color(0xFF58A985)), AppIcon("Messages","✉",Color(0xFF659BD1)),
        AppIcon("Camera","◎",Color(0xFF777D8C)), AppIcon("Photos","✿",Color(0xFFD77F9B)),
        AppIcon("Chrome","◉",Color(0xFF659BD1)), AppIcon("Settings","⚙",Color(0xFF858B98)),
        AppIcon("Music","♫",Color(0xFF9C7CC5)), AppIcon("Calendar","▦",Color(0xFFD28C68)),
        AppIcon("Clock","◷",Color(0xFF659BD1)), AppIcon("Files","▤",Color(0xFFB18D61)),
        AppIcon("Play Store","▷",Color(0xFF58A985)), AppIcon("YouTube","▶",Color(0xFFD66F6F))
    )
    var search by remember { mutableStateOf("") }
    var library by remember { mutableStateOf(false) }
    MaterialTheme(colorScheme = lightColorScheme(background=Color(0xFFF4F2EE), primary=Color(0xFF35404A))) {
        Column(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFFE8E7E3),Color(0xFFF7F5F1),Color(0xFFE9E7E2)))).padding(horizontal=22.dp, vertical=28.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.SpaceBetween) {
                Text(SimpleDateFormat("EEE, d MMM",Locale.getDefault()).format(Date()), color=Color(0xFF62676D), fontSize=14.sp)
                Text("VamsiOS", color=Color(0xFF343A40), fontWeight=FontWeight.SemiBold)
            }
            Spacer(Modifier.height(30.dp))
            Text(SimpleDateFormat("h:mm",Locale.getDefault()).format(Date()), color=Color(0xFF242A30), fontSize=58.sp, fontWeight=FontWeight.Light)
            Text("A little space, beautifully yours.", color=Color(0xFF74777A), fontSize=14.sp)
            Spacer(Modifier.height(25.dp))
            Surface(Modifier.fillMaxWidth(), shape=RoundedCornerShape(26.dp), color=Color.White.copy(alpha=.72f), tonalElevation=1.dp) {
                Column(Modifier.padding(18.dp)) {
                    Text("Good to see you", fontSize=19.sp, fontWeight=FontWeight.SemiBold, color=Color(0xFF30363C))
                    Text("Your day, at a glance.", fontSize=13.sp, color=Color(0xFF777B80))
                }
            }
            Spacer(Modifier.height(20.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.SpaceBetween, verticalAlignment=Alignment.CenterVertically) {
                Text(if(library) "App library" else "Favourites", fontSize=18.sp, fontWeight=FontWeight.SemiBold, color=Color(0xFF333940))
                Text(if(library) "Home" else "See all", color=Color(0xFF687F91), modifier=Modifier.clickable { library=!library })
            }
            if(library) OutlinedTextField(search,{search=it},Modifier.fillMaxWidth(),singleLine=true,placeholder={Text("Search apps")})
            LazyVerticalGrid(columns=GridCells.Fixed(4), modifier=Modifier.weight(1f), horizontalArrangement=Arrangement.spacedBy(10.dp), verticalArrangement=Arrangement.spacedBy(18.dp), contentPadding=PaddingValues(vertical=12.dp)) {
                items((if(library) apps.filter{it.title.contains(search,true)} else apps.take(8))) { app ->
                    Column(horizontalAlignment=Alignment.CenterHorizontally) {
                        Box(Modifier.size(58.dp).clip(RoundedCornerShape(19.dp)).background(app.color.copy(alpha=.17f)), contentAlignment=Alignment.Center) {
                            Text(app.glyph,color=app.color,fontSize=27.sp)
                        }
                        Spacer(Modifier.height(6.dp))
                        Text(app.title,color=Color(0xFF4A5056),fontSize=11.sp,maxLines=1)
                    }
                }
            }
            Surface(shape=RoundedCornerShape(30.dp),color=Color.White.copy(alpha=.78f),modifier=Modifier.fillMaxWidth()) {
                Row(Modifier.padding(vertical=12.dp),horizontalArrangement=Arrangement.SpaceEvenly,verticalAlignment=Alignment.CenterVertically) {
                    listOf("☎","◉","✉","♫").forEachIndexed { i,g ->
                        Box(Modifier.size(48.dp).clip(CircleShape).background(listOf(Color(0xFFDCEBE3),Color(0xFFE5E4EF),Color(0xFFE7EAF0),Color(0xFFF1E4E6))[i]),contentAlignment=Alignment.Center) { Text(g,fontSize=22.sp,color=Color(0xFF59636B)) }
                    }
                }
            }
        }
    }
}
